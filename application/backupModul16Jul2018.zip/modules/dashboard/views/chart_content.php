
 <?php echo $content; ?>
<script src="<?php echo base_url()?>assets/Chartjs/Chart.js"></script>
<script src="<?php echo base_url()?>assets/Chartjs/driver.js"></script>

<script>
    (function () {
        loadChartJsPhp();
    })();
</script>
