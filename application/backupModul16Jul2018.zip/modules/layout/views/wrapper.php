<?php
require_once('head.php');
require_once('header.php');
require_once('menu-sidebar.php');
//require_once('breadcrumb.php');
require_once('contents.php');
require_once('footer.php');